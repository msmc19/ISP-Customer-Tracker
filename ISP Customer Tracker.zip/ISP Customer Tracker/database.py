import sqlite3

# database.py: Handles all database operations such as creating tables, adding, removing, and querying data.

# SQL Statements for creating the necessary tables
CREATE_CUSTOMERS_TABLE = """
CREATE TABLE IF NOT EXISTS Customers (
    customer_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    phone_number TEXT NOT NULL
);
"""

CREATE_LOCATIONS_TABLE = """
CREATE TABLE IF NOT EXISTS Locations (
    location_id INTEGER PRIMARY KEY,
    customer_id INTEGER,
    address TEXT NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);
"""

CREATE_SERVICES_TABLE = """
CREATE TABLE IF NOT EXISTS Services (
    service_id INTEGER PRIMARY KEY,
    location_id INTEGER,
    service_name TEXT NOT NULL,
    cost REAL NOT NULL,
    FOREIGN KEY (location_id) REFERENCES Locations(location_id)
);
"""

CREATE_EQUIPMENT_TABLE = """
CREATE TABLE IF NOT EXISTS Equipment (
    equipment_id INTEGER PRIMARY KEY,
    location_id INTEGER,
    equipment_name TEXT NOT NULL,
    cost REAL NOT NULL,
    FOREIGN KEY (location_id) REFERENCES Locations(location_id)
);
"""

CREATE_BILLING_TABLE = """
CREATE TABLE IF NOT EXISTS Billing (
    billing_id INTEGER PRIMARY KEY,
    customer_id INTEGER,
    amount_due REAL,
    last_payment_date TEXT,
    is_late BOOLEAN,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);
"""

# Establishing the connection to the database and enabling foreign keys
connection = sqlite3.connect("isp_tracking.db")
connection.execute('PRAGMA foreign_keys = ON')

# Function to create all necessary tables
def create_tables():
    with connection:
        connection.execute(CREATE_CUSTOMERS_TABLE)
        connection.execute(CREATE_LOCATIONS_TABLE)
        connection.execute(CREATE_SERVICES_TABLE)
        connection.execute(CREATE_EQUIPMENT_TABLE)
        connection.execute(CREATE_BILLING_TABLE)

# ============================
# Add Functions
# ============================

# Add a new customer to the database
def add_customer(name, phone_number):
    with connection:
        connection.execute("INSERT INTO Customers (name, phone_number) VALUES (?, ?);", (name, phone_number))

# Add a new location for a customer
def add_location(customer_id, address):
    with connection:
        connection.execute("INSERT INTO Locations (customer_id, address) VALUES (?, ?);", (customer_id, address))

# Add a new service to a location
def add_service(location_id, service_name, cost):
    with connection:
        connection.execute("INSERT INTO Services (location_id, service_name, cost) VALUES (?, ?, ?);", (location_id, service_name, cost))

# Add new equipment to a location
def add_equipment(location_id, equipment_name, cost):
    with connection:
        connection.execute("INSERT INTO Equipment (location_id, equipment_name, cost) VALUES (?, ?, ?);", (location_id, equipment_name, cost))

# Add billing information for a customer
def add_billing(customer_id, amount_due, last_payment_date, is_late):
    with connection:
        connection.execute("INSERT INTO Billing (customer_id, amount_due, last_payment_date, is_late) VALUES (?, ?, ?, ?);", (customer_id, amount_due, last_payment_date, is_late))

# ============================
# Remove Functions
# ============================

# Remove a customer from the system
def remove_customer(customer_id):
    with connection:
        connection.execute("DELETE FROM Customers WHERE customer_id = ?", (customer_id,))

# Remove a service from a location
def remove_service(service_id):
    with connection:
        connection.execute("DELETE FROM Services WHERE service_id = ?", (service_id,))

# Remove equipment from a location
def remove_equipment(equipment_id):
    with connection:
        connection.execute("DELETE FROM Equipment WHERE equipment_id = ?", (equipment_id,))

# ============================
# Update Functions
# ============================

# Update the last payment date for a customer and reset late status
def update_last_payment(customer_id, new_payment_date):
    with connection:
        connection.execute("UPDATE Billing SET last_payment_date = ?, is_late = 0 WHERE customer_id = ?", (new_payment_date, customer_id))

# Update the cost of a service
def change_service_cost(service_id, new_cost):
    with connection:
        connection.execute("UPDATE Services SET cost = ? WHERE service_id = ?", (new_cost, service_id))

# Update the cost of equipment
def change_equipment_cost(equipment_id, new_cost):
    with connection:
        connection.execute("UPDATE Equipment SET cost = ? WHERE equipment_id = ?", (new_cost, equipment_id))

# Update the billing amount for a customer
def change_billing_amount(customer_id, new_amount_due):
    with connection:
        connection.execute("UPDATE Billing SET amount_due = ? WHERE customer_id = ?", (new_amount_due, customer_id))

# ============================
# View/Search Functions
# ============================

# Get a customer by their ID
def get_customer_by_id(customer_id):
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Customers WHERE customer_id = ?", (customer_id,))
    return cursor.fetchone()

# Get all locations for a customer
def get_locations_by_customer(customer_id):
    cursor = connection.cursor()
    cursor.execute("SELECT location_id, address FROM Locations WHERE customer_id = ?", (customer_id,))
    return cursor.fetchall()

# Get all services at a specific location
def get_services_by_location(location_id):
    cursor = connection.cursor()
    cursor.execute("SELECT service_name, cost FROM Services WHERE location_id = ?", (location_id,))
    return cursor.fetchall()

# Get all equipment at a specific location
def get_equipment_by_location(location_id):
    cursor = connection.cursor()
    cursor.execute("SELECT equipment_name, cost FROM Equipment WHERE location_id = ?", (location_id,))
    return cursor.fetchall()

# Get billing information for a customer
def get_billing_by_customer(customer_id):
    cursor = connection.cursor()
    cursor.execute("SELECT amount_due, last_payment_date, is_late FROM Billing WHERE customer_id = ?", (customer_id,))
    return cursor.fetchone()

# Search for a customer by name
def search_customer_by_name(name):
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Customers WHERE name LIKE ?", ('%' + name + '%',))
    return cursor.fetchall()

# Search for a customer by location address
def search_customer_by_location(address):
    cursor = connection.cursor()
    cursor.execute("""
        SELECT Customers.customer_id, Customers.name, Customers.phone_number, Locations.address
        FROM Customers
        JOIN Locations ON Customers.customer_id = Locations.customer_id
        WHERE Locations.address LIKE ?
    """, ('%' + address + '%',))
    return cursor.fetchall()

# View all customers who are late on payments
def view_customers_late_on_payment():
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Customers WHERE customer_id IN (SELECT customer_id FROM Billing WHERE is_late = 1)")
    return cursor.fetchall()

# View all registered customers
def view_customers():
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Customers")
    return cursor.fetchall()

# ============================
# Utility Functions
# ============================

# Close the database connection
def close_connection():
    connection.close()
