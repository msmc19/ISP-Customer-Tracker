import database

# main.py: Handles the user interface and interaction with the customer tracking system.
# Prompts the user to select options and calls appropriate functions from database.py

# Organized menu options for the customer tracking system
MENU = '''
================= ISP Customer Tracking System =================

Please select an option from the list below:
------------------------------------------------------------
Customer Management:
1.  Add a New Customer
2.  Remove a Customer
7.  Search for a Customer by Name

Location Management:
3.  Add a New Location for a Customer
8.  Search for a Customer by Location

Service and Equipment Management:
4.  Add a New Service to a Location
5.  Add New Equipment to a Location
11. Remove a Service from a Location
12. Remove Equipment from a Location
13. Update Service Cost
14. Update Equipment Cost

Billing Management:
6.  Add a Billing Record for a Customer
9.  View Customers with Overdue Payments
10. Update Customer's Last Payment Date
15. Update Customer's Billing Amount

Customer Overview:
16. View All Registered Customers

------------------------------------------------------------
17. Exit

------------------------------------------------------------
Enter your selection: '''


# SECTION: Customer Management
# -----------------------------

# Add a new customer to the system
def prompt_add_customer():
    name = input("Customer Name: ")
    phone_number = input("Phone Number: ")
    database.add_customer(name, phone_number)
    print(f"[SUCCESS] New customer '{name}' has been added.\n")


# Remove an existing customer from the system
def prompt_remove_customer():
    customer_id = input("Enter Customer ID to Remove: ")
    database.remove_customer(customer_id)
    print(f"[SUCCESS] Customer ID '{customer_id}' has been removed.\n")


# Search for a customer by their name
def prompt_search_customer_by_name():
    name = input("Enter Customer Name: ")
    results = database.search_customer_by_name(name)
    if results:
        for result in results:
            print(f"Customer ID: {result[0]}, Name: {result[1]}, Phone: {result[2]}")
    else:
        print(f"[INFO] No customers found with name '{name}'.\n")


# SECTION: Location Management
# -----------------------------

# Add a new location for an existing customer
def prompt_add_location():
    customer_id = input("Enter Customer ID: ")
    existing_customer = database.get_customer_by_id(customer_id)
    if not existing_customer:
        print(f"[ERROR] Customer ID '{customer_id}' does not exist.")
        return

    address = input("Location Address: ")
    database.add_location(customer_id, address)
    print(f"[SUCCESS] Location '{address}' added for Customer ID '{customer_id}'.\n")


# Search for a customer by their location
def prompt_search_customer_by_location():
    address = input("Enter Location Address: ")
    results = database.search_customer_by_location(address)
    if results:
        for result in results:
            print(f"Customer ID: {result[0]}, Name: {result[1]}, Phone: {result[2]}, Address: {result[3]}")
    else:
        print(f"[INFO] No customers found at location '{address}'.\n")


# SECTION: Service and Equipment Management
# ------------------------------------------

# Add a new service to a customer's location
def prompt_add_service():
    location_id = input("Enter Location ID: ")
    service_name = input("Service Name: ")
    cost = float(input("Service Cost (in USD): "))
    database.add_service(location_id, service_name, cost)
    print(f"[SUCCESS] Service '{service_name}' added for Location ID '{location_id}'.\n")


# Add new equipment to a customer's location
def prompt_add_equipment():
    location_id = input("Enter Location ID: ")
    equipment_name = input("Equipment Name: ")
    cost = float(input("Equipment Cost (in USD): "))
    database.add_equipment(location_id, equipment_name, cost)
    print(f"[SUCCESS] Equipment '{equipment_name}' added for Location ID '{location_id}'.\n")


# Remove a service from a location
def prompt_remove_service():
    service_id = input("Enter Service ID to Remove: ")
    database.remove_service(service_id)
    print(f"[SUCCESS] Service ID '{service_id}' removed.\n")


# Remove equipment from a location
def prompt_remove_equipment():
    equipment_id = input("Enter Equipment ID to Remove: ")
    database.remove_equipment(equipment_id)
    print(f"[SUCCESS] Equipment ID '{equipment_id}' removed.\n")


# Update the cost of a service for a location
def prompt_change_service_cost():
    service_id = input("Enter Service ID: ")
    new_cost = float(input("New Cost (in USD): "))
    database.change_service_cost(service_id, new_cost)
    print(f"[SUCCESS] Service cost for Service ID '{service_id}' updated.\n")


# Update the cost of equipment for a location
def prompt_change_equipment_cost():
    equipment_id = input("Enter Equipment ID: ")
    new_cost = float(input("New Cost (in USD): "))
    database.change_equipment_cost(equipment_id, new_cost)
    print(f"[SUCCESS] Equipment cost for Equipment ID '{equipment_id}' updated.\n")


# SECTION: Billing Management
# ----------------------------

# Add billing information for a customer
def prompt_add_billing():
    customer_id = input("Enter Customer ID: ")
    amount_due = float(input("Amount Due (in USD): "))
    last_payment_date = input("Last Payment Date (e.g., August 2023): ")
    is_late_input = input("Is the Payment Late? (yes/no): ").strip().lower()
    is_late = 1 if is_late_input == 'yes' else 0 if is_late_input == 'no' else None
    if is_late is None:
        print("[ERROR] Invalid input for 'Is Late'.")
        return

    database.add_billing(customer_id, amount_due, last_payment_date, is_late)
    print(f"[SUCCESS] Billing record added for Customer ID '{customer_id}'.\n")


# View customers who are overdue on their payments
def prompt_view_customers_late_on_payment():
    results = database.view_customers_late_on_payment()
    if results:
        for result in results:
            print(f"Customer ID: {result[0]}, Name: {result[1]}, Phone: {result[2]}")
    else:
        print("[INFO] No customers are currently late on payments.\n")


# Update the last payment date for a customer
def prompt_update_last_payment():
    customer_id = input("Enter Customer ID: ")
    new_payment_date = input("New Last Payment Date: ")
    database.update_last_payment(customer_id, new_payment_date)
    print(f"[SUCCESS] Updated last payment date for Customer ID '{customer_id}'.\n")


# Update the amount due for a customer
def prompt_change_billing_amount():
    customer_id = input("Enter Customer ID: ")
    new_amount_due = float(input("New Amount Due (in USD): "))
    database.change_billing_amount(customer_id, new_amount_due)
    print(f"[SUCCESS] Billing amount for Customer ID '{customer_id}' updated.\n")


# SECTION: Customer Overview
# ---------------------------

# Display customer details (ID, name, phone)
def display_customer_info(customer):
    customer_id, name, phone = customer
    print(f"\nCustomer ID: {customer_id}")
    print(f"Name: {name}")
    print(f"Phone: {phone}")
    print("-------------------------------")


# Display all locations for a customer, with services and equipment
def display_customer_locations(customer_id):
    locations = database.get_locations_by_customer(customer_id)
    if locations:
        print("Locations:")
        for location_id, address in locations:
            print(f"  - Location ID: {location_id}, Address: {address}")
            # Display services and equipment for each location
            display_services_and_equipment(location_id)
    else:
        print("No locations found.")


# Display services and equipment for a specific location
def display_services_and_equipment(location_id):
    services = database.get_services_by_location(location_id)
    if services:
        print("    Services:")
        for service_name, cost in services:
            print(f"      * {service_name} (Cost: ${cost:.2f})")

    equipment = database.get_equipment_by_location(location_id)
    if equipment:
        print("    Equipment:")
        for equip_name, cost in equipment:
            print(f"      * {equip_name} (Cost: ${cost:.2f})")


# Display billing information for a customer
def display_billing_info(customer_id):
    billing = database.get_billing_by_customer(customer_id)
    if billing:
        amount_due, last_payment_date, is_late = billing
        late_status = "Yes" if is_late else "No"
        print("\nBilling Information:")
        print(f"  Amount Due: ${amount_due:.2f}")
        print(f"  Last Payment Date: {last_payment_date}")
        print(f"  Payment Late: {late_status}")
    else:
        print("No billing information available.")


# Main function to view all customers and their associated details
def view_customers():
    customers = database.view_customers()  # Fetch all customers
    if not customers:
        print("[INFO] No customers registered in the system.\n")
        return

    # Iterate through all customers and display their details
    for customer in customers:
        display_customer_info(customer)            # Display basic customer info
        display_customer_locations(customer[0])    # Display locations, services, and equipment
        display_billing_info(customer[0])          # Display billing details



# Main function that displays the menu and handles user input
def main():
    database.create_tables()

    while (user_input := input(MENU)) != '17':
        if user_input == '1':
            prompt_add_customer()
        elif user_input == '2':
            prompt_remove_customer()
        elif user_input == '3':
            prompt_add_location()
        elif user_input == '4':
            prompt_add_service()
        elif user_input == '5':
            prompt_add_equipment()
        elif user_input == '6':
            prompt_add_billing()
        elif user_input == '7':
            prompt_search_customer_by_name()
        elif user_input == '8':
            prompt_search_customer_by_location()
        elif user_input == '9':
            prompt_view_customers_late_on_payment()
        elif user_input == '10':
            prompt_update_last_payment()
        elif user_input == '11':
            prompt_remove_service()
        elif user_input == '12':
            prompt_remove_equipment()
        elif user_input == '13':
            prompt_change_service_cost()
        elif user_input == '14':
            prompt_change_equipment_cost()
        elif user_input == '15':
            prompt_change_billing_amount()
        elif user_input == '16':
            view_customers()
        else:
            print("[ERROR] Invalid selection. Please try again.\n")


if __name__ == "__main__":
    main()
